# Robots Text Processor

This is a Python package to check URL paths against robots directives a robots.txt file.

