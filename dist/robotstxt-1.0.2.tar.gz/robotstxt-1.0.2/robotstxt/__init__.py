from .robots_processing import is_valid_url, select_rule_block, get_url_path
from .processor import robots_file