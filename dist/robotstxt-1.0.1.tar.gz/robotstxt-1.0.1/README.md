# Robots Text Processor

This is a package to handle processing of robots.txt files.

